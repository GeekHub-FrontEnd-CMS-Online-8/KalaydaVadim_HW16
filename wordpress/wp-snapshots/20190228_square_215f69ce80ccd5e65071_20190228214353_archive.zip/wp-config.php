<?php
/**
 * Основные параметры WordPress.
 *
 * Скрипт для создания wp-config.php использует этот файл в процессе
 * установки. Необязательно использовать веб-интерфейс, можно
 * скопировать файл в "wp-config.php" и заполнить значения вручную.
 *
 * Этот файл содержит следующие параметры:
 *
 * * Настройки MySQL
 * * Секретные ключи
 * * Префикс таблиц базы данных
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** Параметры MySQL: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define( 'DB_NAME', 'square' );

/** Имя пользователя MySQL */
define( 'DB_USER', 'root' );

/** Пароль к базе данных MySQL */
define( 'DB_PASSWORD', '' );

/** Имя сервера MySQL */
define( 'DB_HOST', 'localhost' );

/** Кодировка базы данных для создания таблиц. */
define( 'DB_CHARSET', 'utf8mb4' );

/** Схема сопоставления. Не меняйте, если не уверены. */
define( 'DB_COLLATE', '' );

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу.
 * Можно сгенерировать их с помощью {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными. Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'VZF.43Sh$R=.<vc48Va8[AP78d($U^#&.k/Zw2S=4U+B8;~kOT_MUt6pK}~e=v:s' );
define( 'SECURE_AUTH_KEY',  'L<t6nY0CplFa L,Yo7!V;EQIrH%uzW|Qr-,9SJ316:-oa:YXUf`&<vG~{0?U+/t3' );
define( 'LOGGED_IN_KEY',    '0_D~xw&s@&g9ApK{E](Mt4+aU{ c]cuxIG_*0.sw5qtvm7n=-fY.FQ[$24;*gCkb' );
define( 'NONCE_KEY',        'Y?l5)MgL=_53ui;cok~MB3~<3NWr-it]vdU Q{nN.j]}S@(X3aI;LX+C6:z!i9fQ' );
define( 'AUTH_SALT',        'qWV=[{H(Gc`S6Y^!?.+NjZl68LUF}vWqN &>=1}J;WDqD&?EZ<OD7l[>5rM9L:`%' );
define( 'SECURE_AUTH_SALT', 'Df24-HJq6RH9]`@8<Cnaocz-Z=l9 )D*E1:bE9g(KfY26WYM<]#cXp,5lGG &G<;' );
define( 'LOGGED_IN_SALT',   ',*bgoCEc&wpuUWRqbE*LKScbY~~n ^zV5C2XBV8y&AsX[^r5lKd3VD$Mp|Kqd yy' );
define( 'NONCE_SALT',       '-9m/6!Rs=UvMEW!D>[/J)vJi~HuOVW>a[GV7QS`,9L?Z@zh0@A?|w_Obt9@W.yPC' );

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix = 'wp_';

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 *
 * Информацию о других отладочных константах можно найти в Кодексе.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Инициализирует переменные WordPress и подключает файлы. */
require_once( ABSPATH . 'wp-settings.php' );
